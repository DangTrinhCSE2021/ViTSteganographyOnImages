# Vision Transformer Steganography Thesis

This folder contains the complete LaTeX source code for the university thesis on "Vision Transformer-based Image Steganography: A Deep Learning Approach for Robust Watermark Embedding and Extraction".

## 📁 Folder Structure

```
thesis/
├── main.tex                 # Main thesis document
├── title_page.tex          # Title page
├── abstract.tex            # Abstract and keywords
├── acknowledgments.tex     # Acknowledgments
├── references.bib          # Bibliography database
├── appendices.tex          # Technical appendices
├── compile_thesis.bat      # Windows compilation script
├── README.md              # This file
├── chapters/              # Chapter files
│   ├── chapter1_introduction.tex
│   ├── chapter2_literature_review.tex
│   ├── chapter3_methodology.tex
│   ├── chapter4_implementation.tex
│   ├── chapter5_experiments.tex
│   ├── chapter6_results.tex
│   └── chapter7_conclusion.tex
├── figures/               # Generated figures
│   └── (visualization files from thesis_visualizations/)
└── tables/               # Data tables
    └── (performance metrics tables)
```

## 🚀 Quick Start

### Prerequisites

Make sure you have a LaTeX distribution installed:
- **Windows**: MiKTeX or TeX Live
- **macOS**: MacTeX
- **Linux**: TeX Live

Required LaTeX packages (usually auto-installed):
- `geometry` - Page layout
- `setspace` - Line spacing
- `fancyhdr` - Headers and footers
- `titlesec` - Chapter formatting
- `graphicx` - Images and figures
- `booktabs` - Professional tables
- `amsmath` - Mathematical equations
- `hyperref` - Links and bookmarks
- `cite` - Citations
- `float` - Figure positioning

### Compilation

#### Option 1: Use the provided script (Windows)
```bash
# Double-click or run from command prompt
compile_thesis.bat
```

#### Option 2: Manual compilation
```bash
cd thesis/
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

#### Option 3: Using LaTeX editor
Open `main.tex` in your preferred LaTeX editor (TeXStudio, Overleaf, etc.) and compile.

## 📊 Generated Content

### Figures
The thesis includes visualizations generated from the experimental results:
- Training and validation loss curves
- Bit accuracy progression
- Image quality metrics (PSNR, SSIM, MSE)
- Architecture diagrams
- Performance comparison charts

### Tables
- Model architecture specifications
- Training hyperparameters
- Experimental results summary
- Comparison with state-of-the-art methods

## 🔧 Customization

### Modifying Content
- Edit individual chapter files in `chapters/`
- Update bibliography in `references.bib`
- Modify title page information in `title_page.tex`
- Adjust abstract in `abstract.tex`

### Adding Figures
1. Place figure files in `figures/` folder
2. Reference in LaTeX code:
```latex
\begin{figure}[H]
    \centering
    \includegraphics[width=0.8\textwidth]{figures/your_figure.png}
    \caption{Your figure caption}
    \label{fig:your_label}
\end{figure}
```

### Adding Citations
1. Add entries to `references.bib`
2. Cite in text using `\cite{reference_key}`

## 📋 Thesis Structure

### Chapter Overview
1. **Introduction** - Problem statement, objectives, contributions
2. **Literature Review** - Related work in steganography and transformers
3. **Methodology** - Theoretical framework and approach
4. **Implementation** - Technical implementation details
5. **Experiments** - Experimental setup and procedures
6. **Results** - Analysis of experimental results
7. **Conclusion** - Summary, contributions, and future work

### Appendices
- **Appendix A**: Model architecture details
- **Appendix B**: Training hyperparameters
- **Appendix C**: Experimental results details
- **Appendix D**: Implementation code snippets

## 🎯 Key Features

### Academic Standards
- Proper citation format (IEEE style)
- Professional figure and table formatting
- Consistent mathematical notation
- Comprehensive bibliography

### Technical Content
- Detailed methodology description
- Implementation specifics
- Experimental validation
- Performance analysis
- Comparison with existing methods

### Visual Elements
- High-quality figures and diagrams
- Data visualization charts
- Architecture illustrations
- Results comparison tables

## 🛠️ Troubleshooting

### Common Issues

**Missing packages**
```
! LaTeX Error: File `package.sty' not found.
```
Solution: Install missing packages through your LaTeX package manager.

**Bibliography not appearing**
- Make sure to run `bibtex` after first `pdflatex` compilation
- Check that `references.bib` file exists and has valid entries

**Figures not displaying**
- Ensure figure files are in the correct location
- Check file extensions (.png, .pdf, .jpg supported)
- Verify file paths in `\includegraphics{}` commands

**Compilation errors**
- Check LaTeX log file for specific error messages
- Common issues: unmatched braces, undefined commands, missing $

### Getting Help

1. Check LaTeX log files for detailed error messages
2. Verify all required files are present
3. Ensure LaTeX distribution is up to date
4. Test compilation with a minimal example

## 📄 Document Information

- **Title**: Vision Transformer-based Image Steganography
- **Author**: [Your Name]
- **Institution**: [Your University]
- **Degree**: Bachelor of Science in Computer Science
- **Date**: [Submission Date]
- **Pages**: Approximately 80-100 pages
- **Format**: A4, double-sided, 1.5 line spacing

## 🎓 Academic Guidelines

This thesis follows standard academic formatting:
- IEEE citation style
- Proper chapter structure
- Professional table and figure formatting
- Comprehensive literature review
- Detailed experimental validation
- Technical appendices with implementation details

The document is designed to meet university thesis requirements and can be easily customized for different institutions.

## 📈 Experimental Results Summary

The thesis documents the following key achievements:
- **Bit Accuracy**: 50.4% (competitive with state-of-the-art)
- **Image Quality**: PSNR = 42.4 dB, SSIM = 0.9856
- **Robustness**: Tested against JPEG compression, cropping, noise
- **Novelty**: First application of Vision Transformers to image steganography

This comprehensive documentation provides a solid foundation for academic submission and future research in the field of transformer-based steganography.
